# Smart Water Tank Dashboard

## Cara menjalankan di Visual Studio Code
1. Ekstrak folder `smart-water-tank-dashboard`.
2. Buka folder tersebut di Visual Studio Code.
3. Buka `index.html` menggunakan browser, atau gunakan ekstensi **Live Server** lalu klik kanan `index.html` > **Open with Live Server**.

## Fitur
- Dashboard persentase ketinggian air.
- Status pompa ON/OFF.
- Status ketersediaan air sumber.
- Grafik riwayat perubahan level air.
- Kontrol pompa manual.
- Notifikasi otomatis untuk level <=20%, level >=90%, dan sumber kosong.
- Status sistem normal/perhatian.

## Catatan penting
Versi ini adalah **prototype front-end dengan mode simulasi**. Slider dan sakelar simulasi dipakai untuk menguji tampilan, grafik, aturan notifikasi, dan kontrol pada browser. Tombol pompa belum mengendalikan relay/ESP32 sungguhan.

Agar terhubung ke perangkat asli, ESP32 perlu mengirim variabel ke Arduino IoT Cloud. Nama variabel yang disarankan untuk dibuat pada Thing:
- `waterLevel` (float/int, READ)
- `pumpStatus` (bool, READ)
- `sourceAvailable` (bool, READ)
- `manualPump` (bool, READWRITE)
- `systemStatus` (String atau bool, READ)

Samakan nama dan tipe variabel tersebut dengan sketch ESP32. Untuk koneksi web khusus ke Arduino IoT Cloud, gunakan JavaScript SDK resmi atau REST API melalui backend Node.js. Jangan menaruh `client_secret` atau kredensial API di file JavaScript browser.

Dokumentasi resmi:
- https://docs.arduino.cc/cloud-api/
- https://github.com/arduino/arduino-iot-js
- https://docs.arduino.cc/arduino-cloud/guides/overview

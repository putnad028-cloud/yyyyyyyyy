// Dashboard Smart Water Tank - MODE SIMULASI
// Data di bawah ini masih berupa data contoh. Hubungkan ke ESP32/Arduino IoT Cloud
// sebelum digunakan untuk mengendalikan pompa sungguhan.

const state = {
  level: 68,
  pumpOn: false,
  sourceAvailable: true,
  history: [55, 58, 57, 62, 60, 64, 61, 66, 68],
  notices: []
};

const $ = (id) => document.getElementById(id);
const levelValue = $("levelValue");
const levelBar = $("levelBar");
const levelLabel = $("levelLabel");
const pumpValue = $("pumpValue");
const pumpPill = $("pumpPill");
const sourceValue = $("sourceValue");
const sourcePill = $("sourcePill");
const systemValue = $("systemValue");
const systemPill = $("systemPill");
const pumpToggle = $("pumpToggle");
const slider = $("levelSlider");
const sourceToggle = $("sourceToggle");

function addNotice(type, title, message) {
  const key = `${title}-${message}`;
  if (state.notices[0]?.key === key) return;
  state.notices.unshift({ type, title, message, key, time: new Date() });
  state.notices = state.notices.slice(0, 5);
  renderNotices();
}

function evaluateSystem() {
  if (!state.sourceAvailable) {
    state.pumpOn = false;
    addNotice("danger", "Air sumber kosong", "Pompa dimatikan untuk mencegah dry running.");
  } else if (state.level >= 90) {
    state.pumpOn = false;
    addNotice("warning", "Tandon hampir penuh", "Ketinggian air mencapai 90% atau lebih. Pompa dihentikan.");
  } else if (state.level <= 20) {
    state.pumpOn = true;
    addNotice("warning", "Ketinggian air rendah", "Air mencapai 20% atau kurang. Pompa pengisian diaktifkan.");
  }
  render();
}

function render() {
  levelValue.textContent = `${state.level}%`;
  levelBar.style.width = `${state.level}%`;
  $("sliderValue").textContent = `${state.level}%`;
  slider.value = state.level;

  if (state.level <= 20) {
    levelLabel.textContent = "Air rendah";
    levelLabel.className = "pill warning";
  } else if (state.level >= 90) {
    levelLabel.textContent = "Hampir penuh";
    levelLabel.className = "pill warning";
  } else {
    levelLabel.textContent = "Kondisi aman";
    levelLabel.className = "pill safe";
  }

  pumpValue.textContent = state.pumpOn ? "ON" : "OFF";
  pumpPill.textContent = state.pumpOn ? "Sedang mengisi" : "Tidak aktif";
  pumpPill.className = `pill ${state.pumpOn ? "safe" : "neutral"}`;
  $("controlText").textContent = state.pumpOn ? "Pompa sedang aktif" : "Pompa tidak aktif";
  $("controlIndicator").classList.toggle("on", state.pumpOn);
  pumpToggle.textContent = state.pumpOn ? "Matikan Pompa" : "Nyalakan Pompa";

  sourceValue.textContent = state.sourceAvailable ? "Tersedia" : "Kosong";
  sourcePill.textContent = state.sourceAvailable ? "Sumber tersedia" : "Sumber kosong";
  sourcePill.className = `pill ${state.sourceAvailable ? "safe" : "danger"}`;
  sourceToggle.checked = state.sourceAvailable;

  const issue = !state.sourceAvailable || state.level >= 90 || state.level <= 20;
  systemValue.textContent = issue ? "Perhatian" : "Normal";
  systemPill.textContent = !state.sourceAvailable ? "Air sumber kosong" :
    state.level >= 90 ? "Tandon hampir penuh" :
    state.level <= 20 ? "Ketinggian air rendah" : "Semua sistem berjalan";
  systemPill.className = `pill ${issue ? "warning" : "safe"}`;
  $("lastUpdate").textContent = `Update ${new Date().toLocaleTimeString("id-ID")}`;
  drawChart();
}

function renderNotices() {
  $("alertCount").textContent = state.notices.length;
  const list = $("notificationList");
  if (!state.notices.length) {
    list.innerHTML = '<div class="empty-state">Belum ada peringatan. Sistem dalam kondisi normal.</div>';
    return;
  }
  list.innerHTML = state.notices.map(n => `
    <div class="notice ${n.type}">
      <span class="notice-icon">${n.type === "danger" ? "⚠" : n.type === "warning" ? "!" : "ℹ"}</span>
      <div><strong>${n.title}</strong>${n.message}<br><small>${n.time.toLocaleTimeString("id-ID")}</small></div>
    </div>`).join("");
}

function drawChart() {
  const canvas = $("historyChart");
  const ctx = canvas.getContext("2d");
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth;
  const height = 250;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, width, height);

  const left = 35, right = 12, top = 12, bottom = 28;
  const chartW = width - left - right, chartH = height - top - bottom;
  ctx.font = "10px DM Sans, sans-serif";
  ctx.fillStyle = "#91a0b2";
  ctx.strokeStyle = "#e9eef5";
  ctx.lineWidth = 1;

  [0, 25, 50, 75, 100].forEach(v => {
    const y = top + chartH - (v / 100) * chartH;
    ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(width - right, y); ctx.stroke();
    ctx.fillText(`${v}%`, 2, y + 3);
  });

  const points = state.history;
  const coords = points.map((v, i) => ({
    x: left + (i / Math.max(points.length - 1, 1)) * chartW,
    y: top + chartH - (v / 100) * chartH
  }));

  if (coords.length) {
    const gradient = ctx.createLinearGradient(0, top, 0, height - bottom);
    gradient.addColorStop(0, "rgba(35,120,232,.22)");
    gradient.addColorStop(1, "rgba(35,120,232,0)");
    ctx.beginPath();
    coords.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
    ctx.lineTo(coords[coords.length - 1].x, top + chartH);
    ctx.lineTo(coords[0].x, top + chartH);
    ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();

    ctx.beginPath();
    coords.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y));
    ctx.strokeStyle = "#2378e8"; ctx.lineWidth = 3; ctx.stroke();
    const last = coords[coords.length - 1];
    ctx.beginPath(); ctx.arc(last.x, last.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = "#2378e8"; ctx.fill();
  }
  ["Awal", "Terbaru"].forEach((label, i) => {
    ctx.fillStyle = "#91a0b2";
    ctx.fillText(label, i ? width - 48 : left, height - 7);
  });
}

pumpToggle.addEventListener("click", () => {
  if (!state.pumpOn && !state.sourceAvailable) {
    addNotice("danger", "Pompa tidak dapat dinyalakan", "Air sumber kosong. Isi wadah sumber terlebih dahulu.");
    $("controlMessage").textContent = "Perintah ditolak: air sumber tidak tersedia.";
    return;
  }
  if (!state.pumpOn && state.level >= 90) {
    addNotice("warning", "Tandon hampir penuh", "Pompa tidak dapat dinyalakan karena level air sudah mencapai 90%.");
    $("controlMessage").textContent = "Perintah ditolak: tandon sudah hampir penuh.";
    return;
  }
  state.pumpOn = !state.pumpOn;
  $("controlMessage").textContent = "Status pompa simulasi berhasil diperbarui.";
  render();
});

slider.addEventListener("input", () => {
  state.level = Number(slider.value);
  state.history.push(state.level);
  state.history = state.history.slice(-15);
  evaluateSystem();
});

sourceToggle.addEventListener("change", () => {
  state.sourceAvailable = sourceToggle.checked;
  evaluateSystem();
});

$("resetDemo").addEventListener("click", () => {
  state.level = 68;
  state.pumpOn = false;
  state.sourceAvailable = true;
  state.history = [55, 58, 57, 62, 60, 64, 61, 66, 68];
  state.notices = [];
  $("controlMessage").textContent = "Simulasi dikembalikan ke kondisi awal.";
  renderNotices();
  render();
});

function updateClock() {
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString("id-ID");
  $("date").textContent = now.toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
}
window.addEventListener("resize", drawChart);
updateClock();
setInterval(updateClock, 1000);
render();
